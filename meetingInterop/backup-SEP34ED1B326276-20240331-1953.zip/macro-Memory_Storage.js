var memory = {
	"./_$Info": {
		"Warning": "Do NOT modify this document, as other Scripts/Macros may rely on this information", 
		"AvailableFunctions": {
			"local": ["mem.read('key')", "mem.write('key', 'value')", "mem.remove('key')", "mem.print()"],
			"global": ["mem.read.global('key')", "mem.write.global('key', 'value')", "mem.remove.global('key')", "mem.print.global()"]
		},
		"Guide": "https://github.com/Bobby-McGonigle/Cisco-RoomDevice-Macro-Projects-Examples/tree/master/Macro%20Memory%20Storage"
	},
	"ExampleKey": "Example Value"
}