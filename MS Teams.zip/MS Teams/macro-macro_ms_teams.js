import xapi from 'xapi';

var ms_ext_no = ''
var ms_ext_domain = ''
var ms_ext_uri = ''
const internal_domain = 'cumulusorg'

xapi.Event.UserInterface.Extensions.Widget.Action
    .on((event) => {
    if (event.Type == 'clicked'){
      switch (event.WidgetId) {
        case 'ms_int':
            xapi.Command.UserInterface.Message.TextInput.Display(
             { Duration: 300, 
            FeedbackId: 'fb_int_meetingid', 
            InputText: '', 
            InputType: 'Numeric', 
            KeyboardState: 'Open',  
            SubmitText: 'Join', 
            Text: 'Please enter the meeting number', 
            });
            break
        case 'ms_ext_no':
            xapi.Command.UserInterface.Message.TextInput.Display(
             { Duration: 300, 
            FeedbackId: 'fb_ext_meetingid', 
            InputText: '', 
            InputType: 'Numeric', 
            KeyboardState: 'Open',  
            SubmitText: 'Join', 
            Text: 'Please enter the meeting number', 
            });
            break;
        case 'ms_ext_domain':
            xapi.Command.UserInterface.Message.TextInput.Display(
             { Duration: 300, 
            FeedbackId: 'fb_ext_domain', 
            InputText: internal_domain, 
            InputType: 'SingleLine', 
            KeyboardState: 'Open',  
            SubmitText: 'Join', 
            Text: 'Please enter external domain below.', 
            });
            break;   
    }}
    })


xapi.Event.UserInterface.Message.TextInput.Response
    .on(event => {
        console.log(event.FeedbackId)
        if (event.FeedbackId ==  'fb_int_meetingid') {
        const meeting_id = event.Text;
        if (meeting_id) {
          const meeting_uri = meeting_id + '.' + internal_domain + '@m.webex.com';
          xapi.Command.Dial({Number: meeting_uri});
          console.log('dial ' + meeting_uri)
        }
      } else if (event.FeedbackId == 'fb_ext_meetingid') {
          ms_ext_no = event.Text
          console.log(ms_ext_no)
      } else if (event.FeedbackId == 'fb_ext_domain') {
          ms_ext_domain = event.Text
          console.log(ms_ext_domain)
      }
    })


xapi.Event.UserInterface.Extensions.Widget.Action
    .on((event) => {
    if (event.Type == 'clicked' && event.WidgetId == 'ms_ext_join'){
      if (ms_ext_no && ms_ext_domain) {
        ms_ext_uri = ms_ext_no + '.' + ms_ext_domain + '@m.webex.com'
        xapi.Command.Dial({Number: ms_ext_uri})
      } else {
        xapi.Command.UserInterface.Message.Prompt.Display({ Duration: 10, Text: 'Please enter both the meeting number and domain to join a meeting' });
      }
    }
    })
