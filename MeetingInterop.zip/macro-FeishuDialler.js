const xapi = require('xapi');

const VERSION = '0.3.1';
const UPDATE_URL = "https://sf1-dycdn-tos.pstatp.com/obj/eden-cn/upipogbpu/ver.json";
const KEYBOARD_TYPES = {
      NUMERIC     :   'Numeric'
    , SINGLELINE  :   'SingleLine'
    , PASSWORD    :   'Password'
    , PIN         :   'PIN'
}
const CALL_TYPES = {
      AUDIO     :   'Audio'
    , VIDEO     :   'Video'
}

const DIALPAD_ID = 'feishudialpad';
const DIALHOSTPIN_ID = 'feishuhostpin';

const INROOMCONTROL_FEISHUCONTROL_PANELID = 'feishudialler';

/* Use these to check that its a valid number (depending on what you want to allow users to call */

const REGEXP_NUMERICDIALER =  /([a-zA-Z0-9@_\*\-\.]+)/; 

const DIALPREFIX_AUDIO_GATEWAY = '';
const DIALPOSTFIX_FEISHUURL = '@lvc.feishu.cn';

var feishunumbertodial = '';
var hostpin = '';
var isInFeishuCall = 0;

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

xapi.event.on('CallDisconnect', (event) => {
	isInFeishuCall = 0;
    });
    
    
    
function showDialPad(text){

         xapi.command("UserInterface Message TextInput Display", {
               InputType: KEYBOARD_TYPES.NUMERIC
             , Placeholder: '9位飞书会议号'
             , Title: "飞书"
             , Text: text
             , SubmitText: "拨打" 
             , FeedbackId: DIALPAD_ID
         }).catch((error) => { console.error(error.message); });
}

/* This is the listener for the in-room control panel button that will trigger the dial panel to appear */
xapi.event.on('UserInterface Extensions Panel Clicked', (event) => {
    if(event.PanelId === INROOMCONTROL_FEISHUCONTROL_PANELID){
         showDialPad("输入飞书会议号（9位）" );
    }
});



xapi.event.on('UserInterface Message TextInput Response', (event) => {
    switch(event.FeedbackId){
        case DIALPAD_ID:
            let regex = REGEXP_NUMERICDIALER; // First check, is it a valid number to dial
            let match = regex.exec(event.Text);    
            if (match !== null) {
                let contains_at_regex = /@/;    
                let contains_at_in_dialstring = contains_at_regex.exec(event.Text);
                if (contains_at_in_dialstring !== null) {
                    feishunumbertodial = match[1];
                }
                else{
                    feishunumbertodial = match[1];
                    feishunumbertodial = DIALPREFIX_AUDIO_GATEWAY + feishunumbertodial + DIALPOSTFIX_FEISHUURL ; // Here we add the default hostname to the SIP number 
                }
                 sleep(200).then(() => { //this is a necessary trick to get it working with multiple touch panels to not mess up event-clears from other panels
  
                 // xapi.command("UserInterface Message TextInput Display", {
                 //       InputType: KEYBOARD_TYPES.PIN
                 //     , Placeholder: "会议密码（可选）" 
                 //     , Title: "输入会议密码，没有可不填"
                 //     , Text: '飞书会议：' + feishunumbertodial
                 //     , SubmitText: "拨打" 
                 //     , FeedbackId: DIALHOSTPIN_ID
                 // }).catch((error) => { console.error(error.message); });    
                             
                 xapi.command("dial", {Number: feishunumbertodial}).catch((error) => { console.error(error.message); });
            });
                   
            }
            else{
                showDialPad("输入的会议号不正确。请输入9位飞书会议号" );
            }
            break;

        case DIALHOSTPIN_ID:
            hostpin = event.Text;
            xapi.command("dial", {Number: feishunumbertodial}).catch((error) => { console.error(error.message); });
            break;
    }
});



xapi.status.on('Call RemoteNumber', (remoteNumber) => {
	if(remoteNumber.includes('bytedance.com')){
	    isInFeishuCall = 1;
	    sleep(5000).then(() => {
		    if(isInFeishuCall){ // need to check again in case call has dropped within the last 5 seconds
                if(hostpin.length>0){
                  xapi.command("Call DTMFSend", {DTMFString: hostpin});  
                    if(!hostpin.includes('#')){
                        xapi.command("Call DTMFSend", {DTMFString: '#'});
                    }
                } 
                else{
                    xapi.command("Call DTMFSend", {DTMFString: '#'});
                }
		    }		    
		});
	}
    });

// setInterval(() => {
//   xapi.config.set('HttpClient Mode', 'On');
//   xapi.config.set('HttpClient AllowHTTP', 'True');
//   xapi.config.set('HttpClient AllowInsecureHTTPS', 'True');
  
//   xapi.command('HttpClient Get', { 'Url': UPDATE_URL, 'AllowInsecureHTTPS': 'True'}).then((result) => {
//     let body = result.Body;
//     let description = JSON.parse(body);
//     if (description.version != VERSION) {
//       let params = {'Mode': 'Replace'};
//       if (description.checksum) {
//         params.Checksum = description.checksum;
//       }
//       if (description.algorithm) {
//         params.ChecksumType = description.algorithm;
//       }
//       if (description.url) {
//         params.URL = description.url;
//       } else
//       if (description.file) {
//         params.URL = UPDATE_URL.replace(/[^\/]*$/, description.file);
//       } else {
//         params.URL = UPDATE_URL.replace(/[^\/]*$/, 'dialler-' + description.version + '.zip');
//       }
//       xapi.command('Provisioning Service Fetch', params).catch((error) => { console.error(error.message); });
//     }
//   }).catch((error) => { console.error(error.message); });
// }, 48 * 60 * 60 * 1000);

console.info('FeishuDialler ' + VERSION + ' initialized.');