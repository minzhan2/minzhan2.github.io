/**
* A small UI Extensions panel with Teams quick dial
*/
const xapi = require('xapi');
// These match the widget ids of the UI Extensions buttons
const numbers = {
Teams: 'catering@example.com',
};
function dial(number) {
console.log('dial', number);
xapi.command('dial', { Number: 'cumulusorg@m.webex.com' });
}
function listenToGui() {
xapi.event.on('UserInterface Extensions Panel Clicked', (event) => { const number = numbers[event.PanelId];
console.log(number);
if (number) dial(number);
else console.log('Unknown button pressed', event.WidgetId);
});
}
listenToGui();

