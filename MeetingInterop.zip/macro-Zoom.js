const xapi = require('xapi');

const KEYBOARD_TYPES = {
    NUMERIC: 'Numeric'
    , SINGLELINE: 'SingleLine'
    , PASSWORD: 'Password'
    , PIN: 'PIN'
}

const zoomconfbridge = { 'beijing':'zoomcrc.com','guangzhou':'81.71.29.245','hongkong':'101.32.38.23'}

const DIALPAD_ID = 'webexdialpad';
const DIALHOSTPIN_ID = 'webexhostpin';

const INROOMCONTROL_WEBEXCONTROL_PANELID = 'Zoom';

/* Use these to check that its a valid number (depending on what you want to allow users to call */
const REGEXP_URLDIALER = /([a-zA-Z0-9@_\-\.]+)/; /*  . Use this one if you want to allow URL dialling */
const REGEXP_NUMERICDIALER = /^([0-9]{3,10})$/; /* Use this one if you want to limit calls to numeric only. In this example, require number to be between 3 and 10 digits. */



var webexnumbertodial = '';
var hostpin = '';
var isInWebexCall = 0;
var tencentMeeting = { 'number': '', 'hostpin': '', 'terminalSipUri': '' };

function init() {
    xapi.config.set('HttpClient Mode', 'On'); //this needs to be set to on to allow HTTP Post
    xapi.config.set('HttpClient AllowHTTP', 'True'); //this needs to be set to on to allow HTTP
    xapi.config.set('HttpClient AllowInsecureHTTPS', 'True'); //this needs to be set to on to allow HTTPS
    xapi.config.get('SIP URI').then(v => {
        tencentMeeting.terminalSipUri = v;
        console.log('SIP', v)
    });
}

function handleError(error) {
    console.log('Error', error);
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

xapi.event.on('CallDisconnect', (event) => {
    isInWebexCall = 0;
});

function showDialPad(text) {
    xapi.command("UserInterface Message TextInput Display", {
        InputType: KEYBOARD_TYPES.NUMERIC
        , Placeholder: '0-9 数字或字母'
        , Title: "Zoom会议号"
        , Text: text
        , SubmitText: "下一步"
        , FeedbackId: DIALPAD_ID
    }).catch(handleError);
}

/* This is the listener for the in-room control panel button that will trigger the dial panel to appear */
xapi.event.on('UserInterface Extensions Panel Clicked', (event) => {
    if (event.PanelId === INROOMCONTROL_WEBEXCONTROL_PANELID) {
        showDialPad("请您输入Zoom会议号:");
    }
});

xapi.event.on('UserInterface Message TextInput Response', (event) => {
    switch (event.FeedbackId) {
        case DIALPAD_ID:
            let regex = REGEXP_URLDIALER; // First check, is it a valid number to dial
            let match = regex.exec(event.Text);
            if (match !== null) {
                let contains_at_regex = /@/;
                let contains_at_in_dialstring = contains_at_regex.exec(event.Text);
                if (contains_at_in_dialstring !== null) {
                    webexnumbertodial = match[1];
                }
                else {
                    webexnumbertodial = match[1];
                    //webexnumbertodial = webexnumbertodial + DIALPOSTFIX_WEBEXURL; // Here we add the default hostname to the SIP number 
                }
                sleep(200).then(() => { //this is a necessary trick to get it working with multiple touch panels to not mess up event-clears from other panels
                    let res = webexnumbertodial.replace(/^(.{3})(.{3})(.*)$/, '$1 $2 $3');
                    xapi.command("UserInterface Message TextInput Display", {
                        InputType: KEYBOARD_TYPES.NUMERIC
                        , Placeholder: "密码(可选)"
                        , Title: "请输入密码或空"
                        , Text: 'Zoom会议号:' + res
                        , SubmitText: "加入"
                        , FeedbackId: DIALHOSTPIN_ID
                    }).catch(handleError);

                });

            }
            else {
                showDialPad("您输入的会议号格式是不可用的。请重新输入。例如：blablabla...");
            }
            break;

        case DIALHOSTPIN_ID:
            tencentMeeting.hostpin = hostpin = event.Text;
            tencentMeeting.number = webexnumbertodial;
            vms_join_meeting(tencentMeeting);
            //xapi.command("dial", {Number: webexnumbertodial}).catch(handleError);
            break;
    }
});

xapi.status.on('Call RemoteNumber', (remoteNumber) => {
    if (remoteNumber.includes('webex.com')) {
        isInWebexCall = 1;
        sleep(5000).then(() => {
            if (isInWebexCall) { // need to check again in case call has dropped within the last 5 seconds
                if (hostpin.length > 0) {
                    xapi.command("Call DTMFSend", { DTMFString: hostpin });
                    if (!hostpin.includes('#')) {
                        xapi.command("Call DTMFSend", { DTMFString: '#' });
                    }
                }
                else {
                    xapi.command("Call DTMFSend", { DTMFString: '#' });
                }
            }
        });
    }
});

/* IP of hue bridge. If bridge is connected directly to one of the network ports of a codec this will be 192.168.96.118 */
const vms_api_root_path = '/api/v1/client/vms';
const VMS_API_REST_HEADER = 'Content-Type: application/json';
const HTTP_TIMEOUT = 1; /* How fast (in seconds) the HTTP rest commands should fail with timeout error. */


function vms_get(path) {
    var url = vms_baseURL + path;
    xapi.command('HttpClient Get', { 'Header': [VMS_API_REST_HEADER, SERVICENOW_AUTHTOKEN], 'Url': url, 'AllowInsecureHTTPS': 'True' })
        .then((result) => {
            console.log("success:" + result.StatusCode);
            if (result.StatusCode == 200) {
                var jsonObject = JSON.parse(result.Body);
                console.log(jsonObject.paths);
            }
        })
        .catch(handleError);
}

function getServiceNowIncidentIdFromURL(url) {
    return xapi.command('HttpClient Get', { 'Header': [VMS_API_REST_HEADER, SERVICENOW_AUTHTOKEN], 'Url': url, 'AllowInsecureHTTPS': 'True' });
}

function vms_join_meeting(data) {
    var dialurl = tencentMeeting.number+'**'+tencentMeeting.hostpin+'@'+ zoomconfbridge.beijing
    console.log(' Zoom会议号:',dialurl);
    dialurl = tencentMeeting.number + '@' + zoomconfbridge.beijing
    xapi.command("dial", { Number: dialurl }).catch(handleError);
}

init();