const xapi = require('xapi');

const KEYBOARD_TYPES = {
    NUMERIC: 'Numeric'
    , SINGLELINE: 'SingleLine'
    , PASSWORD: 'Password'
    , PIN: 'PIN'
}

const DIALPAD_ID = 'wemeetdialpad';
const DIALHOSTPIN_ID = 'wemeetdialpadpin';

// message string
const DIALPAD_PLACEHOLDER_MSG = '请输入会议号';
const DIALPAD_TITLE_MSG = '加入腾讯会议';
const DIALPAD_SUBMIT_TEXT_MSG = '下一步';
const DIALPAD_MSG = '请输入腾讯会议号:';
const MEETING_CODE_ERROR_MSG = '您输入的会议号有误, 请检查后重新输入';

const INROOMCONTROL_WEMEET_CONTROL_PANELID = 'wemeetdialler';
const SERVER_POSTFIX = '@qqmra.com';

/* Use these to check that its a valid number (depending on what you want to allow users to call */
const REGEXP_URLDIALER = /([a-zA-Z0-9@_\-\.\*]+)/; /*  . Use this one if you want to allow URL dialling */
const REGEXP_NUMERICDIALER = /^([0-9]{3,10})$/; /* Use this one if you want to limit calls to numeric only. In this example, require number to be between 3 and 10 digits. */

var meeting_code = '';
var wemeetnumbertodial = '';
var hostpin = '';
var isInWemeetCall = 0;
var tencentMeeting = { 'number': '', 'hostpin': '', 'terminalSipUri': '' };

function init() {
    xapi.config.set('HttpClient Mode', 'On'); //this needs to be set to on to allow HTTP Post
    xapi.config.set('HttpClient AllowHTTP', 'True'); //this needs to be set to on to allow HTTP
    xapi.config.set('HttpClient AllowInsecureHTTPS', 'True'); //this needs to be set to on to allow HTTPS
    xapi.config.get('SIP URI').then(v => {
        tencentMeeting.terminalSipUri = v;
        console.log('SIP', v)
    });
}

function handleError(error) {
    console.log('Error', error);
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

xapi.event.on('CallDisconnect', (event) => {
    console.log('quit meeting', wemeetnumbertodial);
    isInWemeetCall = 0;
});

function showDialPad(text) {
    xapi.command("UserInterface Message TextInput Display", {
        InputType: KEYBOARD_TYPES.NUMERIC
        , Placeholder: DIALPAD_PLACEHOLDER_MSG
        , Title: DIALPAD_TITLE_MSG
        , Text: text
        , SubmitText: DIALPAD_SUBMIT_TEXT_MSG
        , FeedbackId: DIALPAD_ID
    }).catch(handleError);
}

/* This is the listener for the in-room control panel button that will trigger the dial panel to appear */
xapi.event.on('UserInterface Extensions Panel Clicked', (event) => {
    if (event.PanelId === INROOMCONTROL_WEMEET_CONTROL_PANELID) {
        showDialPad(DIALPAD_MSG);
    }
});

xapi.event.on('UserInterface Message TextInput Response', (event) => {
    switch (event.FeedbackId) {
        case DIALPAD_ID:
            let regex = REGEXP_URLDIALER; // First check, is it a valid number to dial
            let match = regex.exec(event.Text);
            if (match !== null) {
                let contains_at_regex = /@/;
                let contains_at_in_dialstring = contains_at_regex.exec(event.Text);
                if (contains_at_in_dialstring !== null) {
                    console.log('branch DIALPAD_ID @ existing, out string', wemeetnumbertodial);
                    meeting_code = wemeetnumbertodial.split("@")[0]
                } else {
                    console.log('branch DIALPAD_ID @ not existing');
                    meeting_code = match[1]
                    console.log('meeting code', meeting_code);
                }
                sleep(200).then(() => { //this is a necessary trick to get it working with multiple touch panels to not mess up event-clears from other panels
                    xapi.command("UserInterface Message TextInput Display", {
                        InputType: KEYBOARD_TYPES.NUMERIC
                        , Placeholder: "密码(可选)"
                        , Title: "请输入密码或空"
                        , Text: '腾讯会议号:' + meeting_code
                        , SubmitText: "加入"
                        , FeedbackId: DIALHOSTPIN_ID
                    }).catch(handleError);

                });
            }
            else {
                showDialPad(MEETING_CODE_ERROR_MSG);
            }
            break;
    case DIALHOSTPIN_ID:
        tencentMeeting.hostpin = event.Text;
        wemeetnumbertodial = meeting_code;
        if (tencentMeeting.hostpin != '') {
            wemeetnumbertodial = meeting_code + '**' + tencentMeeting.hostpin;
        }
        wemeetnumbertodial = wemeetnumbertodial + SERVER_POSTFIX;
        console.log('outgoing string', wemeetnumbertodial);
        xapi.command("dial", {Number: wemeetnumbertodial}).catch(handleError);
    }
});

xapi.status.on('Call RemoteNumber', (remoteNumber) => {
    if (remoteNumber.includes('wemeet.com')) {
        isInWemeetCall = 1;
        sleep(5000).then(() => {
            if (isInWemeetCall) { // need to check again in case call has dropped within the last 5 seconds
                if (hostpin.length > 0) {
                    xapi.command("Call DTMFSend", { DTMFString: hostpin });
                    if (!hostpin.includes('#')) {
                        xapi.command("Call DTMFSend", { DTMFString: '#' });
                    }
                }
                else {
                    xapi.command("Call DTMFSend", { DTMFString: '#' });
                }
            }
        });
    }
});

init();